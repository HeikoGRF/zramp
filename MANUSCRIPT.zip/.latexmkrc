# Enable bibtex run and delegate shared configuration to the project-level
# shared rc. Compute its absolute path and `do` it so this file stays minimal.
use Cwd;
my $shared = Cwd::abs_path('.latexmkrc.shared');
do $shared;

# # Test to ensure that the project-specific latexmkrc is loaded and configured correctly.
# print "--- Loaded project-specific latexmkrc ---\n";

# # Makes out the output directory
# $out_dir = 'out';
# $aux_dir = 'out';

# # Use pdflatex
# $pdf_mode = 1;

# # Avoid hanging on errors
# $pdflatex = 'pdflatex -interaction=nonstopmode %O %S';

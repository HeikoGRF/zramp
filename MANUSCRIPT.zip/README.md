# Project Template

- `paper.tex` contains the paper resulting from the work (main document)
- `guidelines.tex` contains a set of rules to write content in the paper
- `report.tex` contains the final report for official submission (Research Report)

Important: This repo is dual-compatible for Overleaf and local compilation. For local compilation, the environment variable `LATEXMK_USE_OUTDIR` must be set to 1
# Enable bibtex run and delegate shared configuration to the project-level
# shared rc. Compute its absolute path and `do` it so this file stays minimal.
use Cwd;
my $shared = Cwd::abs_path('../.latexmkrc.shared');
do $shared;
